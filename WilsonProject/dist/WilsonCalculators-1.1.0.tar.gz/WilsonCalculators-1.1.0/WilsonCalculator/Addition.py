
# This is developed by Wilson Shamim
# this module will perform addition on 2 numbers
# 2 input parametes of type int

print("Performing Addition:")
def add(x,y):
    return x+y

