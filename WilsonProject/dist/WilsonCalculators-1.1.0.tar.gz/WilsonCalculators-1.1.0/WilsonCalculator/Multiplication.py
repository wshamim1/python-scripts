
# This is developed by Wilson Shamim
# this module will perform Multiplication on 2 numbers
# 2 input parametes of type int

print("Performing Multiplication>:")
def Mul(x,y):
    return x*y

