
# This is developed by Wilson Shamim
# this module will perform Subtraction on 2 numbers
# 2 input parametes of type int

print("Performing subtraction...:")
def sub(x,y):
    return x-y

